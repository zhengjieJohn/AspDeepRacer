﻿using FYPJ_DeepRacer.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FYPJ_DeepRacer.BLL
{
    public class User
    {
        public string email { get; set; }
        public string password { get; set; }
        public string salt { get; set; }
        public string name { get; set; }
        public string contactno { get; set; }

        public User()
        {

        }

        public User(string Email, string Password, string Salt, string Name, string ContactNo)
        {
            email = Email;
            password = Password;
            salt = Salt;
            name = Name;
            contactno = ContactNo;

        }

        public int AddUser()
        {
            UserDAO dao = new UserDAO();
            int result = dao.Insert(this);
            return result;
        }

        public int UpdateUser()
        {
            UserDAO dao = new UserDAO();
            int result = dao.Update(this);
            return result;
        }

        public List<User> GetAllUser()
        {
            UserDAO dao = new UserDAO();
            return dao.SelectAll();
        }

        public List<User> GetUserById2(string Email)
        {
            UserDAO dao = new UserDAO();
            return dao.SelectById2(Email);
        }

        public User GetUserById(string Email)
        {
            UserDAO dao = new UserDAO();
            return dao.SelectById(Email);
        }

        public int UpdatePassword()
        {
            UserDAO dao = new UserDAO();
            int result = dao.UpdatePW(this);
            return result;
        }
    }
}