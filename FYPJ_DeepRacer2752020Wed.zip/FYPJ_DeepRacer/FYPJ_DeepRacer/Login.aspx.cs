﻿using FYPJ_DeepRacer.BLL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FYPJ_DeepRacer
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LoginBtn_Click(object sender, EventArgs e)
        {
            EmailMsg.Text = String.Empty;
            PasswordMsg.Text = String.Empty;
            ErrorMsg.Text = "";

            User user = new User();

            string email = inputEmail.Text;
            string password = inputPassword.Text;

            string mystr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
            SqlConnection myConn = new SqlConnection(mystr);
            myConn.Open();

            string sqlStr = "Select Email, Password, Salt FROM [User] WHERE Email = @paraEmail ";
            SqlCommand cmd = new SqlCommand(sqlStr, myConn);
            cmd.Parameters.AddWithValue("@paraEmail", email);

            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dt);

            if (inputEmail.Text == "" && inputPassword.Text == "")
            {
                EmailMsg.Text += "Email is required!";
                EmailMsg.ForeColor = Color.Red;
                PasswordMsg.Text += "Password is required!" + "<br/>";
                PasswordMsg.ForeColor = Color.Red;
            }
            else if (inputEmail.Text == "")
            {
                PasswordMsg.Text += "";
                EmailMsg.Text += "Email is required!";
                EmailMsg.ForeColor = Color.Red;
            }
            else if (inputPassword.Text == "")
            {
                EmailMsg.Text += "";
                PasswordMsg.Text += "Password is required!" + "<br/>";
                PasswordMsg.ForeColor = Color.Red;
            }
            else if (user.GetUserById(inputEmail.Text) == null)
            {
                EmailMsg.Text += "";
                PasswordMsg.Text += "";
                ErrorMsg.Text += "No such user. Have u signed up?" + "<br/>";
                ErrorMsg.ForeColor = Color.Red;
            }
            else
            {
                string pwd_db = dt.Rows[0]["Password"].ToString();
                string salt = dt.Rows[0]["Salt"].ToString();
                byte[] passwordAndSaltBytes = System.Text.Encoding.UTF8.GetBytes(password + salt);
                byte[] hashBytes = new System.Security.Cryptography.SHA256Managed().ComputeHash(passwordAndSaltBytes);
                string hashString = Convert.ToBase64String(hashBytes);
                if (hashString == pwd_db)
                {
                    Response.Redirect("Home.aspx");
                }
                else
                {
                    EmailMsg.Text += "";
                    PasswordMsg.Text += "";
                    ErrorMsg.Text += "Incorrect Password and/or Email!" + "<br/>";
                    ErrorMsg.ForeColor = Color.Red;
                }
            }
        }

        protected void LoginBtn_Click1(object sender, EventArgs e)
        {
            
        }
    }
}