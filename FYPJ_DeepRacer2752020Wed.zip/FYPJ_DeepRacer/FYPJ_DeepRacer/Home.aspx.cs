﻿using FYPJ_DeepRacer.BLL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FYPJ_DeepRacer
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnContact_Click(object sender, EventArgs e)
        {
            
         

            Debug.WriteLine("This is test");
            int result = 0;
            SqlCommand sqlCmd = new SqlCommand();

            string name = TBContactName.Text;
            string email = TBContactEmail.Text;
            string subject = TBContactSubject.Text;
            string message = TAMessage.Text;
          
            string mystr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
            SqlConnection myConn = new SqlConnection(mystr);
            myConn.Open();

            string sqlStmt = "INSERT INTO[ContactUs] (tdContactUs_Name, tdContactUs_Email,tdContactUs_Subject, tdContactUs_Message) " +
                "VALUES (@paraCUName, @paraCUEmail, @paraCUSubject, @paraCUMessage)";
            sqlCmd = new SqlCommand(sqlStmt, myConn);

            sqlCmd.Parameters.AddWithValue("@paraCUName", name);
            sqlCmd.Parameters.AddWithValue("@paraCUEmail", email);
            sqlCmd.Parameters.AddWithValue("@paraCUSubject", subject);
            sqlCmd.Parameters.AddWithValue("@paraCUMessage", message);

            sqlCmd.ExecuteNonQuery();

        }

        protected void LoginBtn_Click(object sender, EventArgs e)
        {
            //EmailMsg.Text = String.Empty;
            //PasswordMsg.Text = String.Empty;
            //ErrorMsg.Text = "";

            //User user = new User();

            ////string email = EmailMsg.Text;
            //string password = PasswordMsg.Text;

            //string mystr = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
            //SqlConnection myConn = new SqlConnection(mystr);
            //myConn.Open();

            //string sqlStr = "Select Email, Password, Salt FROM [User] WHERE Email = @paraEmail ";
            //SqlCommand cmd = new SqlCommand(sqlStr, myConn);
            //cmd.Parameters.AddWithValue("@paraEmail", email);

            //DataTable dt = new DataTable();
            //SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            //adapter.Fill(dt);

        }
    }
}