﻿using FYPJ_DeepRacer.BLL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FYPJ_DeepRacer
{
    public partial class SignUpPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private bool ValidateInput()
        {
            bool result;
            EmailMsg.Text = String.Empty;
            PasswordMsg.Text = String.Empty;
            NameMsg.Text = String.Empty;
            ContactNoMsg.Text = String.Empty;

            if (inputEmail.Text == "")
            {
                EmailMsg.Text += "Email is required!";
                EmailMsg.ForeColor = Color.Red;
            }
            if (String.IsNullOrEmpty(inputPassword.Text))
            {
                PasswordMsg.Text += "Password is required!" + "<br/>";
                PasswordMsg.ForeColor = Color.Red;
            }
            if (inputPassword.Text != cfmPassword.Text)
            {
                PasswordMsg.Text += "Passwords do not match!" + "<br/>";
                PasswordMsg.ForeColor = Color.Red;
            }
            if (String.IsNullOrEmpty(inputName.Text))
            {
                NameMsg.Text += "Name is required!";
                NameMsg.ForeColor = Color.Red;
            }
            if (String.IsNullOrEmpty(inputContactNo.Text))
            {
                ContactNoMsg.Text += "Contact Number is required!";
                ContactNoMsg.ForeColor = Color.Red;
            }

            if (String.IsNullOrEmpty(EmailMsg.Text) && String.IsNullOrEmpty(PasswordMsg.Text) && String.IsNullOrEmpty(NameMsg.Text) && String.IsNullOrEmpty(ContactNoMsg.Text))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            User user = new User();
            ErrorMsg.Text = String.Empty;

            if (user.GetUserById(inputEmail.Text) != null)
            {
                // pop up textbox
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('User exists! Please try again.');</script>");
            }
            else
            {
                if (ValidateInput())
                {

                    user = new User(inputEmail.Text, inputPassword.Text, "Salt", inputName.Text, inputContactNo.Text);
                    int result = user.AddUser();
                    if (result == 1)
                    {
                        ErrorMsg.Text = "User created! Redirecting to the login page shortly.";
                        ErrorMsg.ForeColor = Color.Green;
                        Response.AddHeader("REFRESH", "3;URL=Login.aspx");
                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Error in adding record!');</script>");
                    }
                }               
            }
        }
    }
}