﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FYPJ_DeepRacer
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!IsPasswordResetLinkValid())
                {
                    ErrorMsg.ForeColor = System.Drawing.Color.Red;
                    ErrorMsg.Text = "Password Reset link has expired or is invalid";
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string newpassword = TbPassword1.Text;
            string cfmpassword = TbPassword2.Text;

            if (newpassword == cfmpassword)
            {
                if (ChangeUserPassword() == true)
                {
                    ErrorMsg.Text = "Password Changed Successfully. Proceed to login now!";
                    ErrorMsg.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    ErrorMsg.ForeColor = System.Drawing.Color.Red;
                    ErrorMsg.Text = "Password Reset link has expired or is invalid";
                }
            }
            else
            {
                ErrorMsg.Text += "Password not matched!" + "<br/>";
                ErrorMsg.ForeColor = Color.Red;
            }
        }

        private bool ChangeUserPassword()
        {
            string cfmpassword = TbPassword2.Text;

            System.Security.Cryptography.RNGCryptoServiceProvider rng = new System.Security.Cryptography.RNGCryptoServiceProvider();
            byte[] saltBytes = new byte[36];
            rng.GetBytes(saltBytes);
            string salt = Convert.ToBase64String(saltBytes);

            byte[] passwordAndSaltBytes = System.Text.Encoding.UTF8.GetBytes(cfmpassword + salt);
            byte[] hashBytes = new System.Security.Cryptography.SHA256Managed().ComputeHash(passwordAndSaltBytes);
            string hashString = Convert.ToBase64String(hashBytes);

            List<SqlParameter> paramList = new List<SqlParameter>()
            {
                new SqlParameter()
                {
                    ParameterName = "@GUID",
                    Value = Request.QueryString["uid"]
                },
                new SqlParameter()
                {
                    ParameterName = "@Password",
                    Value = hashString
                },
                new SqlParameter()
                {
                    ParameterName = "@Salt",
                    Value = salt
                }
            };
            return ExecuteSP("spChangePassword", paramList);
        }

        //Check password is valid or expired
        private bool IsPasswordResetLinkValid()
        {
            List<SqlParameter> paramList = new List<SqlParameter>()
            {
                new SqlParameter()
                {
                    ParameterName = "@GUID",
                    Value = Request.QueryString["uid"]
                }
            };
            return ExecuteSP("spIsPasswordResetLinkValid", paramList);
        }

        private bool ExecuteSP(string SPName, List<SqlParameter> SPParameters)
        {
            string CS = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand(SPName, con);
                cmd.CommandType = CommandType.StoredProcedure;

                foreach (SqlParameter parameter in SPParameters)
                {
                    cmd.Parameters.Add(parameter);
                }

                con.Open();
                return Convert.ToBoolean(cmd.ExecuteScalar()); // 1 or 0
            }
        }
    }
}